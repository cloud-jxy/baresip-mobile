/**
 * @file gst/gst.h  Gstreamer playbin pipeline -- internal interface
 *
 * Copyright (C) 2010 Creytiv.com
 */


void gst_dump_props(GstElement *g);
void gst_dump_caps(const GstCaps *caps);
