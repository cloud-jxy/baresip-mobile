/**
 * @file gst1/gst.h  Gstreamer playbin pipeline -- internal interface
 *
 * Copyright (C) 2010 Creytiv.com
 */


